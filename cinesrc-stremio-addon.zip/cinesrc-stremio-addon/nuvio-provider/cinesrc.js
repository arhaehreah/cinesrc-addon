/**
 * CineSrc provider for NuvioStreams
 * ─────────────────────────────────
 * Drop this file into the NuvioStreams `providers/` directory and add
 * the following line to the provider registry in addon.js / server.js:
 *
 *   const cinesrc = require('./providers/cinesrc');
 *   // then push `cinesrc` into the providers array
 *
 * CineSrc uses TMDB IDs.  NuvioStreams already resolves IMDb → TMDB IDs
 * upstream, so this provider receives `tmdbId` directly.
 *
 * Because CineSrc delivers an embed page (not a raw .m3u8 or .mp4 URL),
 * the stream is returned as an `externalUrl` — Stremio opens it in its
 * built-in WebView, exactly as it does with other embed providers.
 */

"use strict";

const CINESRC_BASE = "https://cinesrc.st/embed";

const DEFAULT_OPTS = {
  autoskip:  process.env.CINESRC_AUTOSKIP  === "true",
  autonext:  process.env.CINESRC_AUTONEXT  !== "false",  // default ON
  quality:   process.env.CINESRC_QUALITY   || "1080",
  color:     (process.env.CINESRC_COLOR    || "#e50914").replace("#", "%23"),
  seek:      Number(process.env.CINESRC_SEEK) || 10,
  febbox:    process.env.CINESRC_FEBBOX    || "",         // premium token (optional)
};

/**
 * Build the CineSrc embed URL.
 *
 * @param {"movie"|"tv"} type
 * @param {string|number} tmdbId
 * @param {number|string} [season]
 * @param {number|string} [episode]
 * @returns {string}
 */
function buildUrl(type, tmdbId, season, episode) {
  const base =
    type === "movie"
      ? `${CINESRC_BASE}/movie/${tmdbId}`
      : `${CINESRC_BASE}/tv/${tmdbId}?s=${season}&e=${episode}`;

  const params = new URLSearchParams();

  if (DEFAULT_OPTS.autoskip)  params.set("autoskip",  "true");
  if (!DEFAULT_OPTS.autonext) params.set("autonext",  "false");
  if (DEFAULT_OPTS.quality)   params.set("quality",   DEFAULT_OPTS.quality);
  if (DEFAULT_OPTS.color)     params.set("color",     DEFAULT_OPTS.color);
  if (DEFAULT_OPTS.seek !== 10) params.set("seek",    String(DEFAULT_OPTS.seek));
  if (DEFAULT_OPTS.febbox)    params.set("febbox",    DEFAULT_OPTS.febbox);

  const qs = params.toString();
  const sep = base.includes("?") ? "&" : "?";
  return qs ? `${base}${sep}${qs}` : base;
}

// ── Provider API ─────────────────────────────────────────────────────────────

const provider = {
  name: "CineSrc",
  // Set to false in your .env to disable this provider:
  enabled: process.env.CINESRC_ENABLED !== "false",

  /**
   * Fetch streams for a movie.
   *
   * @param {{ tmdbId: string }} meta
   * @returns {Promise<Array>}
   */
  async getMovieStreams({ tmdbId }) {
    if (!this.enabled) return [];
    if (!tmdbId) {
      console.warn("[CineSrc] No TMDB ID – skipping movie.");
      return [];
    }

    const url = buildUrl("movie", tmdbId);
    console.log(`[CineSrc] Movie embed → ${url}`);

    return [makeStream(url)];
  },

  /**
   * Fetch streams for a TV episode.
   *
   * @param {{ tmdbId: string, season: number, episode: number }} meta
   * @returns {Promise<Array>}
   */
  async getEpisodeStreams({ tmdbId, season, episode }) {
    if (!this.enabled) return [];
    if (!tmdbId) {
      console.warn("[CineSrc] No TMDB ID – skipping episode.");
      return [];
    }

    const url = buildUrl("tv", tmdbId, season, episode);
    console.log(`[CineSrc] Episode embed → ${url}`);

    return [makeStream(url, season, episode)];
  },
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function makeStream(externalUrl, season, episode) {
  const desc = season
    ? `S${String(season).padStart(2, "0")}E${String(episode).padStart(2, "0")} • Multiple servers • No P2P`
    : "Multiple servers • No P2P";

  return {
    name:        "CineSrc",
    description: desc,
    externalUrl,
    behaviorHints: { notWebReady: false },
  };
}

module.exports = provider;
